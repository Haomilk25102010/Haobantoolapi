<?php
//========================================================================
// Author:  Pascal KISSIAN
// Resume:  http://pascal.kissian.net
//
// Copyright (c) 2015-2020 Pascal KISSIAN
//
// Published under the MIT License
//          Consider it as a proof of concept!
//          No warranty of any kind.
//          Use and abuse at your own risks.
//========================================================================

class myPrettyprinter extends PhpParser\PrettyPrinter\Standard
{
    private function obfuscate_string($str)
    {
      $key = 5;
      return implode('', array_map(fn($char) => chr(ord($char) + $key), str_split($str)));
    }


    public function pScalar_String(PhpParser\Node\Scalar\String_ $node)
    {
        $result = $this->obfuscate_string($node->value);            if (!strlen($result)) return "''";
        return  'implode("", array_map(fn($char) => chr(ord($char) - key), str_split("'.$this->obfuscate_string($node->value).'")))';
    }


    //TODO: pseudo-obfuscate HEREDOC string
    protected function pScalar_Encapsed(PhpParser\Node\Scalar\Encapsed $node)
    {
        $result = '';
        foreach ($node->parts as $element)
        {
            if ($element instanceof PhpParser\Node\Scalar\EncapsedStringPart)
            {
                $result .=  $this->obfuscate_string($element->value);
            }
            else
            {
                $result .= '{' . $this->p($element) . '}';
            }
        }
        return 'implode("", array_map(fn($char) => chr(ord($char) - key), str_split("'.$result.'")))';
    }
}

?>